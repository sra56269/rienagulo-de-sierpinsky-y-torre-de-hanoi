public class Principal {

    /**
     * metodo principal que corre el triangulo
     *
     * @param args
     */
    public static void main(String[] args) {
  
        String[] a = new String[1];
  
        //aqui se le da el tamañoo del triangulo
        a[0] = "5";
  
        //se llama al metodo pincipal de la clase sierpinsky
        Sierpinsky.main(a);
  
    }
  
  }
  
  